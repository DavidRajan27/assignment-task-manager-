const taskForm = document.getElementById('taskForm');
const tasksList = document.getElementById('tasks');
const filterStatus = document.getElementById('filterStatus');

// Fetch and display tasks
function fetchTasks() {
    const status = filterStatus.value;
    fetch(`php/get_tasks.php?status=${status}`)
        .then(response => response.json())
        .then(tasks => {
            tasksList.innerHTML = ''; // Clear the current list
            tasks.forEach(task => {
                // Create a list item for each task
                const taskItem = document.createElement('li');
                taskItem.className = 'task-item';
                taskItem.innerHTML = `
                    <div>
                        <h3>${task.title}</h3>
                        <p>${task.description}</p>
                        <span class="status">Status: ${task.status}</span>
                    </div>
                    <button onclick="deleteTask(${task.id})">Delete</button>
                `;
                tasksList.appendChild(taskItem); // Add task to the list
            });
        })
        .catch(error => console.error('Error fetching tasks:', error));
}

// Add task
taskForm.addEventListener('submit', (e) => {
    e.preventDefault(); // Prevent form submission
    const taskTitle = document.getElementById('taskTitle').value;
    const taskDescription = document.getElementById('taskDescription').value;
    const taskStatus = document.getElementById('taskStatus').value;

    // Validate form data
    if (!taskTitle || !taskStatus) {
        alert('Please fill in all required fields!');
        return;
    }

    // Prepare form data for POST
    const formData = new FormData();
    formData.append('title', taskTitle);
    formData.append('description', taskDescription);
    formData.append('status', taskStatus);

    fetch('php/add_task.php', {
        method: 'POST',
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            alert(data.message || data.error);
            taskForm.reset(); // Clear the form
            fetchTasks(); // Refresh the task list
        })
        .catch(error => console.error('Error adding task:', error));
});

// Delete task
function deleteTask(id) {
    fetch('php/delete_task.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${id}`, // Send task ID to be deleted
    })
        .then(response => response.json())
        .then(data => {
            alert(data.message || data.error);
            fetchTasks(); // Refresh the task list
        })
        .catch(error => console.error('Error deleting task:', error));
}

// Filter tasks
filterStatus.addEventListener('change', () => {
    fetchTasks(); // Refetch tasks based on the selected status
});

// Initial fetch of tasks
fetchTasks();
