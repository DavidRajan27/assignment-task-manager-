<?php
include 'assignment(db).php';

$id = $_POST['id'];
$title = $_POST['title'];
$description = $_POST['description'];
$status = $_POST['status'];

if (empty($id) || empty($title) || empty($status)) {
    echo json_encode(['error' => 'ID, Title, and Status are required!']);
    exit;
}

$sql = "UPDATE tasks SET title = ?, description = ?, status = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('sssi', $title, $description, $status, $id);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Task updated successfully!']);
} else {
    echo json_encode(['error' => 'Error updating task: ' . $conn->error]);
}
?>
