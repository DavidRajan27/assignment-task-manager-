<?php
include 'assignment(db).php';

$title = $_POST['title'];
$description = $_POST['description'];
$status = $_POST['status'];

if (empty($title) || empty($status)) {
    echo json_encode(['error' => 'Title and status are required!']);
    exit;
}

$sql = "INSERT INTO tasks (title, description, status) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param('sss', $title, $description, $status);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Task added successfully!']);
} else {
    echo json_encode(['error' => 'Error adding task: ' . $conn->error]);
}
?>
