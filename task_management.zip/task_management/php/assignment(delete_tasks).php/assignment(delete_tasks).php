<?php
include 'assignment(db).php';

$id = $_POST['id'];

if (empty($id)) {
    echo json_encode(['error' => 'Task ID is required!']);
    exit;
}

$sql = "DELETE FROM tasks WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Task deleted successfully!']);
} else {
    echo json_encode(['error' => 'Error deleting task: ' . $conn->error]);
}
?>
