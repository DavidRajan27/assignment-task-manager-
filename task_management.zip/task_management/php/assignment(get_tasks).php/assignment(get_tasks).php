<?php
include 'assignment(db).php';

$status = $_GET['status'];
$sql = "SELECT * FROM tasks";

if ($status !== 'All tasks') {
    $sql .= " WHERE status = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $status);
} else {
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();

$tasks = [];
while ($row = $result->fetch_assoc()) {
    $tasks[] = $row;
}

echo json_encode($tasks);
?>
